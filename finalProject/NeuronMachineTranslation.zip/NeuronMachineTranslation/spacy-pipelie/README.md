---
license: apache-2.0
language:
- bg
library_name: spacy
pipeline_tag: token-classification
metrics:
- accuracy
- f1
---

# Pretrained spaCy model of Bulgarian language

Full paper: [An Improved Bulgarian Natural Language Processing Pipeline](https://annual.uni-sofia.bg/index.php/fmi/article/view/572/559).

Presentation [here](https://docs.google.com/presentation/d/1igrxFjlWuPxZuU9mDI1_H23iYA7Rq6D4/edit?usp=sharing&ouid=108163209901619891277&rtpof=true&sd=true).

# Usage
For information how to use the model, refer to the [GitHub repository of the project](https://github.com/melaniab/spacy-pipeline-bg).

# Reference

If you use the pipeline in your academic project, please cite as:

```bibtex
@article
{berbatova2023improved,
title={An improved Bulgarian natural language processing pipelihttps://github.com/melaniab/spacy-pipeline-bgne},
author={Berbatova, Melania and Ivanov, Filip},
journal={Annual of Sofia University St. Kliment Ohridski. Faculty of Mathematics and Informatics},
volume={110},
pages={37--50},
year={2023}
}
```

If you use this model in non-academic project, such as study project or industry application, please give me a note at melania.berbatova@gmail.com.