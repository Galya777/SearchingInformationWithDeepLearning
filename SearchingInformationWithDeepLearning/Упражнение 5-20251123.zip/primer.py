from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import numpy as np


def randrange(n, x0, y0, z0, x1, y1, z1):
	t = np.linspace(0,1,num=n)

	xs = x0*t + x1*(1-t) + np.random.normal(0,0.8,n)
	ys = y0*t + y1*(1-t) + np.random.normal(0,0.4,n)
	zs = z0*t + z1*(1-t) + np.random.normal(0,0.1,n)
	return xs, ys, zs

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

ax.set_xlim([0,10])
ax.set_ylim([0,10])
ax.set_zlim([0,10])

xs, ys, zs = randrange(500,1,1,1,10,7,8)
ax.scatter(xs, ys, zs)

ax.quiver(np.mean(xs),np.mean(ys),np.mean(zs), 5*0.71785218,5*0.45287068,5*0.52876876,color='r')
ax.quiver(np.mean(xs),np.mean(ys),np.mean(zs), 2*-0.67802988,2*0.62714251,2*0.38336373,color='r')

plt.show()

from sklearn.decomposition import PCA
X = np.stack([xs,ys,zs]).transpose()
X -= np.mean(X, axis=0)

n_samples = X.shape[0]
cov_matrix = np.dot(X.T, X) / n_samples


pca = PCA(n_components=2)
pca.fit(X)
print(pca.explained_variance_)
print(pca.components_)
X_ = pca.transform(X)

pca.components_


X_x = X_[:,0]
X_y = X_[:,1]

plt.plot(X_x,X_y,'o')
plt.show()
