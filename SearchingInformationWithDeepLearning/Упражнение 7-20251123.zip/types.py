#! /bin/python3 -u
import numpy as np

def f(x : int) -> str | None:
    if x < 10:
        return "Hello"

m : dict[int, tuple[str, int]]= {x : str(x) for x in range(10)}

f(m)

class Point[T] :
    def __init__(self, x : T, y : T) :
        self.x = x
        self.y = y

def k(p : Point[int]) -> np.ndarray:
    p.x += 10
    return np.zeros((10,10));

print(f(5))
print(f(20))
print(f("asd"))
